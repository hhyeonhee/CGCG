#include <QMainWindow>

class QtEditor : public QMainWindow {
	Q_OBJECT
public:
	QtEditor();

public slots:
	int newFile();
	int openFile();
};