#include <QMenuBar>
#include <QMenu>
#include <QToolBar>
#include <QStatusBar>
#include <QAction>
#include <QIcon>
#include <QTextEdit>
#include <QMessageBox>
#include <QFileDialog>
#include <QWorkspace>

#include "QtEditor.h"

QtEditor::QtEditor()
{
	QMenu* fileMenu;
	QToolBar* toolbar;
	QStatusBar* startusbar;
	QWorkspace* workspace = new QWorkspace;
	QTextEdit* textedit = new QTextEdit;
	
	QAction* newAct = new QAction(QIcon("images/new.png"), "&New", this);
        newAct->setShortcut(tr("Ctrl+N"));
        newAct->setStatusTip(tr("make new file"));
        connect(newAct, SIGNAL(triggered()), this, SLOT(newFile()));

	QAction* openAct = new QAction(QIcon("images/open.png"), "&Open", this);
        openAct->setShortcut(tr("Ctrl+O"));
        openAct->setStatusTip(tr("Open existing file"));
        connect(openAct, SIGNAL(triggered()), this, SLOT(openFile()));
	
	
	fileMenu = menuBar()->addMenu("File");
	fileMenu->addAction(newAct);
	fileMenu->addAction(openAct);

	toolbar = addToolBar("New");
	toolbar->addAction(newAct);
	toolbar->addAction(openAct);
		
        startusbar = statusBar();
        setCentralWidget(workspace);
        workspace->addWindow(textedit);
	
}

int QtEditor::newFile()
{
	QMessageBox::information(this, "Open", "File Open.");
	return 0;
}
	
int QtEditor::openFile()
{
#if 1
	QFileDialog* fileDlG = new QFileDialog(this);
      	fileDlG->setFileMode(QFileDialog::AnyFile);
      	fileDlG->exec();
#else
	QErrorMessage* errorMsgDlg = new QErrorMessage(this);
	errorMsgDlg->showMessage ("Error Message");
	errorMsgDlg->exec();
#endif
	return 0;
}
	
