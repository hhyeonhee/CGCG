#include <QWidget>
#include <QDialog>
#include <QTabWidget>

class QtTabDialog : public QDialog {
	Q_OBJECT
public:
	QtTabDialog(QWidget *parent = 0);

private:
	QTabWidget* tabwidget;
	QWidget *tab_1;
	QWidget *tab_2;	
	QWidget *tab_3;
};