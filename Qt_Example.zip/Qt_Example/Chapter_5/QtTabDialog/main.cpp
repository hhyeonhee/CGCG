#include <QApplication>

#include "QtTabDialog.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	QtTabDialog* qttabdialog = new QtTabDialog();
	qttabdialog->exec();
	
	return app.exec();
}