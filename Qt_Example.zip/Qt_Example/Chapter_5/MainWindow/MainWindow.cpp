#include <QMenuBar>
#include "MainWindow.h"

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent)
{
 #if 0
        QMenuBar* menubar = new QMenuBar();
        setMenuBar(menubar);
#else
        menuBar();
#endif
}
