#include <QPainterPath>
#include <QPainter>
#include <QApplication>
#include <QWidget>

class Paint : public QWidget
{
public:
    Paint(){ resize(200,200); };

private:
    void paintEvent( QPaintEvent* );
    QPainterPath paintpath1;
    QPainterPath paintpath2;
    QPainter painter;
};

void Paint::paintEvent( QPaintEvent* )
{
    paintpath1.setFillRule(Qt::OddEvenFill);	// Default Value
    paintpath1.moveTo(0.0, 100.0);
    paintpath1.cubicTo(21.0, 10.0, 14.0, 52.0, 100.0, 100.0);
    paintpath1.closeSubpath();

    paintpath1.moveTo(20.0, 30.0);
    paintpath1.lineTo(20.0, 80.0);
    paintpath1.lineTo(80.0, 80.0);
    paintpath1.lineTo(80.0, 30.0);
    paintpath1.lineTo(20.0, 30.0);

    paintpath2.setFillRule( Qt::WindingFill );
    paintpath2.addRect(120.0, 120.0, 60.0, 60.0);
    paintpath2.addEllipse(100.0, 100.0, 70.0, 70.0);

    painter.begin(this);
    painter.setBrush(Qt::blue);
    painter.drawPath(paintpath1);
    painter.setBrush(Qt::green);
    painter.drawPath(paintpath2);
    painter.end();
}

int main(int argc, char** argv)
{
  QApplication app(argc, argv);

  Paint p;
  p.show();

  return app.exec();
}
