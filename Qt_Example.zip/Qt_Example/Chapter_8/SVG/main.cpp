#include <QWidget>
#include <QApplication>
#include <QPainter>
#include <QSvgWidget>
#include <QSvgRenderer>

class SVGWidget : public QWidget
{
public:
    SVGWidget(const QString filename);
    QSvgWidget* svgw;

    void paintEvent(QPaintEvent *);
};

SVGWidget::SVGWidget(const QString filename)
{
    resize(300, 300); 
    svgw = new QSvgWidget(filename);
}

void SVGWidget::paintEvent(QPaintEvent *)
{
    QImage buffer = QImage(size(), QImage::Format_ARGB32_Premultiplied);

    QPainter painter(&buffer);
    painter.setViewport(0, 0, width(), height());
    painter.eraseRect(0, 0, width(), height());
   
    svgw->renderer()->render(&painter);
    QPainter pt(this);
    pt.drawImage(0, 0, buffer);
};

int main(int argc, char** argv)
{
  QApplication app(argc, argv);
  SVGWidget p(argv[1]);

  p.show();

  return app.exec();
}
