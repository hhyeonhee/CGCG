#include <QPainter>
#include <QWidget>
#include <QApplication>

class Paint : public QWidget
{
public:
    Paint(){ resize(200,200); };

private:
    void paintEvent( QPaintEvent* );
    QPainter *paint;
};

void Paint::paintEvent( QPaintEvent* )
{
  paint = new QPainter;

  paint->begin( this );

  paint->setPen( QPen(Qt::blue, 5, Qt::SolidLine ) );

  paint->drawRoundRect(20, 20, 160, 160); 
  
  paint->end();
}

int main(int argc, char** argv)
{
  QApplication app(argc, argv);

  Paint p;

  p.show();

  return app.exec();
}
