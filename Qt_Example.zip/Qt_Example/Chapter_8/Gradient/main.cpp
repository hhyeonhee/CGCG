#include <QPainterPath>
#include <QPainter>
#include <QApplication>
#include <QWidget>

class Paint : public QWidget
{
public:
    Paint(){ resize(200,200); };

private:
    void paintEvent( QPaintEvent* );
    QPainter painter;
};

void Paint::paintEvent( QPaintEvent* )
{
    QRadialGradient gradient(102, 102, 85);
    gradient.setColorAt(0.0, Qt::red);
    gradient.setColorAt(0.5, Qt::blue);
    gradient.setColorAt(1.0, Qt::green);

    painter.begin(this);
    painter.setBrush(gradient);
    painter.drawEllipse(20, 20, 170, 170);
    painter.end();
}

int main(int argc, char** argv)
{
  QApplication app(argc, argv);

  Paint p;
  p.show();

  return app.exec();
}
