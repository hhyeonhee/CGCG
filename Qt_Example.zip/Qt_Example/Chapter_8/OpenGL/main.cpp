#include <qgl.h>
#include <qapplication.h>
#include <stdio.h>

class PaintWidget : public QGLWidget
{
 public:
  PaintWidget(QWidget* parent = 0);

  void paintGL();
  void resizeGL(int w, int h);
};

PaintWidget::PaintWidget(QWidget* parent) : QGLWidget(parent)
{
  resize(160, 120);
//  glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
}

void PaintWidget::paintGL()
{
 glClear(GL_COLOR_BUFFER_BIT);
 qglColor(Qt::white);
 renderText(50.0, 60.0, 0.0, QString("Hello Qt"));
}

void PaintWidget::resizeGL(int w, int h)
{
 printf("W : %d, H : %d\n", w, h);

 glViewport(0, 0, (GLint)w, (GLint)h);
 glMatrixMode(GL_PROJECTION);     
 glLoadIdentity();
 glOrtho(0, w, 0, h, -1, 1);
 glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv)
{
 QApplication app(argc, argv);
 PaintWidget pw;
 pw.show();
 return app.exec();
}

