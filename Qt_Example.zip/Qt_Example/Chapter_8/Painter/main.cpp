#include <QPainter>
#include <QApplication>
#include <Qwidget>
#include <QFileDialog>
#include <QPicture>

class Paint : public QWidget
{
public:
    Paint(){ resize(200,200); };

private:
    void paintEvent( QPaintEvent* );
    QPainter *paint;
};

void Paint::paintEvent( QPaintEvent* )
{
  QString file("sa.jpg");
  QFileDialog dlg;
  file = dlg.getOpenFileName(this, "Choose Image File", "/", "Image File(*.jpg *.bmp)");

  paint = new QPainter;
  paint->begin( this );

  QImage        i;
  if ( i.load( file ) )
     paint->drawImage( 0, 0, i);
  
  paint->end();
}

int main(int argc, char** argv)
{
  QApplication app(argc, argv);

  Paint p;

  p.show();

  return app.exec();
}
