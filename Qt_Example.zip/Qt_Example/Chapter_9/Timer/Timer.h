#include <QWidget>
#include <QTimer>
#include <QLabel>
 
class TimerWindow : public QWidget
{ 
        Q_OBJECT
public:
        TimerWindow(QWidget* parent = 0, Qt::WFlags fl = 0);
        ~TimerWindow();
 
private:
        QLabel* TextLabel; 
        QTimer* TimerWindow1;
        QTimer* TimerWindow2;
 
private slots:
        void MyTimerWindow1();
        void MyTimerWindow2();
};
