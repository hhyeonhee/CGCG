#include "Timer.h"

TimerWindow::TimerWindow(QWidget* parent, Qt::WFlags fl) : QWidget(parent, fl)
{
         resize( 120, 41 ); 
         TextLabel = new QLabel(this);
         TextLabel->setGeometry( QRect( 20, 10, 81, 20 ) ); 
         TextLabel->setText( "Timer1" );
 
         TimerWindow1 = new QTimer(this);
         connect(TimerWindow1, SIGNAL( timeout() ), SLOT( MyTimerWindow1() ) );
         if(!TimerWindow1->isActive()) TimerWindow1->start( 1000 );
 
         TimerWindow2 = new QTimer( this );
         connect(TimerWindow2, SIGNAL( timeout() ), SLOT( MyTimerWindow2() ) );
         if(!TimerWindow2->isActive()) TimerWindow2->start( 1500 );
}


TimerWindow::~TimerWindow()
{
       TimerWindow1->stop();
       disconnect(TimerWindow1);
 
       TimerWindow2->stop();
       disconnect(TimerWindow2);
}
 
void TimerWindow::MyTimerWindow1()
{
         TextLabel->setText( "One" );
}
 
void TimerWindow::MyTimerWindow2()
{
        TextLabel->setText( "Two" );
}
