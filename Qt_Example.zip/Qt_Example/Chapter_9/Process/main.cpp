#include <QApplication>
#include <QTextEdit>
#include <QProcess>
#include <QByteArray>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);

        QProcess cmd_ls;
        cmd_ls.start("ls", QStringList() << "-l");   //  cmd_ls.start("ls -l");

        if (!cmd_ls.waitForStarted()) return false;

        if (!cmd_ls.waitForFinished()) return false;

        QByteArray result = cmd_ls.readAllStandardOutput(); // readAll();

	QTextEdit* edit = new QTextEdit;
        edit->setReadOnly(TRUE);
        edit->append(result);
        edit->show();

        app.exec(); 
}
