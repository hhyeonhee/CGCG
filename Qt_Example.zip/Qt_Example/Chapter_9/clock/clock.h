#ifndef __LABEL_CLOCK_H__
#define __LABEL_CLOCK_H__

#include <QLabel>
#include <QTimer>
#include <QTime>
#include <QWidget>

class LabelClock : public QWidget {
    Q_OBJECT

public:
        LabelClock(QWidget *parent = 0);

private:
        QLabel* clock;
        QTimer* timer; 
        QTime time;

public slots:
        void clockTimer();
};
#endif                          /* __LABEL_CLOCK_H__ */
