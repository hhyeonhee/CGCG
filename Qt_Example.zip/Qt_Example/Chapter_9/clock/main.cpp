#include <QApplication>

#include "clock.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	LabelClock* clock = new LabelClock;
	clock->show();
	
	return app.exec();
}
