#include "clock.h"

LabelClock::LabelClock(QWidget *parent) : QWidget(parent)
{
        clock = new QLabel(this);
        clock->resize(80, 20);

        timer = new QTimer(this);
        QObject::connect( timer, SIGNAL(timeout()), SLOT(clockTimer()) );
        timer->start( 1000 );                 // 1 seconds

        resize(90, 40);
}

void LabelClock::clockTimer()
{
        time = QTime::currentTime();
#if 0
        QString str = QString("%1:%2:%3") \
                         .arg(time.hour(), 2) \
                         .arg(time.minute(), 2) \
                         .arg(time.second(), 2);
#else
        QString str = time.toString();
#endif
        clock->setText(str); 
}
