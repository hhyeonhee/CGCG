#include "ThreadWindow.h"

ThreadDlg::ThreadDlg(QWidget* parent, Qt::WFlags fl) : QWidget(parent, fl)
{

    label = new QLabel(this);
    thread = new Thread(label);

    stopButton = new QPushButton("Stop", this);
    resumeButton = new QPushButton("Resume", this);

    QHBoxLayout* hboxlayout = new QHBoxLayout;
    hboxlayout->addWidget(stopButton);
    hboxlayout->addWidget(resumeButton);

    QVBoxLayout* vboxlayout = new QVBoxLayout;
    vboxlayout->addWidget(label);
    vboxlayout->addLayout(hboxlayout);

    setLayout(vboxlayout);

    connect(stopButton, SIGNAL( clicked() ), this, SLOT( stopThread() ) );
    connect(resumeButton, SIGNAL( clicked() ), this, SLOT( resumeThread() ) );

    thread->start();
}

ThreadDlg::~ThreadDlg()
{
    thread->wait();
}

void ThreadDlg::stopThread()
{
    thread->stop();
}

void ThreadDlg::resumeThread()
{
    thread->resume();
}

