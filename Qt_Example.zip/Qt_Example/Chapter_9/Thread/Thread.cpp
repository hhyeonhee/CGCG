#include "ThreadWindow.h"

#define STOP    0
#define PLAY    1

Thread::Thread(QObject* obj)
{
    m_label = (QLabel*)obj;
    m_stopflag = PLAY;
}

void Thread::run()
{

    for(int count = 0;;) {
        m_mutex.lock();
        if(m_stopflag == STOP)
            m_waitCondition.wait(&m_mutex);
        m_mutex.unlock();

        m_label->setText( QString("run %1").arg(count++));
        sleep(1);
    };
}

void Thread::stop()
{
    m_stopflag = STOP;
}

void Thread::resume()
{
    m_mutex.lock();
    m_stopflag = PLAY;
    m_waitCondition.wakeAll();
    m_mutex.unlock();
}

