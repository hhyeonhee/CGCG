#include <QApplication>

#include "ThreadWindow.h"

int main(int argc, char** argv)
{
    QApplication app(argc, argv);
    ThreadDlg* thread = new ThreadDlg;
    thread->show();

    return app.exec();
}
