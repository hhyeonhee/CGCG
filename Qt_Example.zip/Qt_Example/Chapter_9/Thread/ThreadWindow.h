#include <QtGui>
#include <QWidget>

#include "Thread.h"

class ThreadDlg : public QWidget
{
        Q_OBJECT

  public:
    ThreadDlg(QWidget* parent = 0, Qt::WFlags fl = 0);
    ~ThreadDlg();

  private:
    Thread* thread;
    QLabel* label;
    QPushButton* stopButton;
    QPushButton* resumeButton;

  public slots:
    void stopThread();  
    void resumeThread();  
};
