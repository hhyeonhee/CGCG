#include <QThread>
#include <QMutex>
#include <QWaitCondition>
#include <QLabel>

class Thread : public QThread {
   Q_OBJECT

  public:
    Thread(QObject* obj);
    void stop();
    void resume();
    QWaitCondition m_waitCondition;
    QMutex m_mutex;
    qint32 m_stopflag;

  private:
    void run();
    QLabel* m_label;
};
