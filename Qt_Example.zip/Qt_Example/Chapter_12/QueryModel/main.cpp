#include <QApplication>
#include <QTableView>
#include <QSqlQueryModel>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

static bool createConnection()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(":memory:");
    if (!db.open()) return false;

    QSqlQuery query;
    query.exec("create table person (id int primary key, "
               "firstname varchar(20), lastname varchar(20))");
    query.exec("insert into person values(101, 'Yongsu', 'Kang')");
    query.exec("insert into person values(102, 'Soomi', 'Kim')");
    query.exec("insert into person values(103, 'Hanmi', 'Lee')");
    query.exec("insert into person values(104, 'YoungJin', 'Suh')");
    query.exec("insert into person values(105, 'YoungHwa', 'Ryu')");

    return true;
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    if (!createConnection()) return 1;

    QSqlQueryModel QueryModel;
    QueryModel.setQuery("select * from person");
    QueryModel.setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    QueryModel.setHeaderData(1, Qt::Horizontal, QObject::tr("First name"));
    QueryModel.setHeaderData(2, Qt::Horizontal, QObject::tr("Last name"));

    QTableView *tableview = new QTableView;
    tableview->setModel(&QueryModel);
    tableview->setWindowTitle(QObject::tr("Query Model"));
    tableview->show();

    return app.exec();
}
