#include <QApplication>
#include <QSpinBox>

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        QSpinBox* SP = new QSpinBox();
        SP->setRange( 0, 10 );
        SP->setWrapping( TRUE );
        SP->setSpecialValueText("Hi");
        SP->show();

        return app.exec();
}
