#include <QApplication>
#include <QWidget>
#include <QCheckBox>
#include <QButtonGroup>

class CheckBox : public QWidget
{
public:
        CheckBox();

private:
        QCheckBox* CheckBox1;
        QCheckBox* CheckBox2;
        QCheckBox* CheckBox3;
        QCheckBox* CheckBox4;

        QButtonGroup *ButtonGroup;
};

CheckBox::CheckBox()
{
        resize(130, 110);

        ButtonGroup = new QButtonGroup( this );

        CheckBox1 = new QCheckBox("CheckBox1", this);
        CheckBox1->move(10,10);
        ButtonGroup->addButton(CheckBox1);
        CheckBox2 = new QCheckBox("CheckBox2", this);
        CheckBox2->move(10,30);
        ButtonGroup->addButton(CheckBox2);
        CheckBox3 = new QCheckBox("CheckBox3", this);
        CheckBox3->move(10,50);
        ButtonGroup->addButton(CheckBox3);
        CheckBox4 = new QCheckBox("CheckBox4", this);
        CheckBox4->move(10,70);
        ButtonGroup->addButton(CheckBox4);
        
		ButtonGroup->setExclusive(false);        
}

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        CheckBox CheckBoxWindow;
        CheckBoxWindow.show();

        return app.exec();
}
