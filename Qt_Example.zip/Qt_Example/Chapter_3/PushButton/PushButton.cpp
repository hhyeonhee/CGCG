#include <QApplication>
#include <QPushButton>

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        QPushButton *PushButton = new QPushButton("Push&Button", 0);
        PushButton->setShortcut(Qt::Key_Control+Qt::Key_C);

        PushButton->show();

        QObject::connect(PushButton, SIGNAL(clicked()), &app, SLOT( quit() ) );

        return app.exec();
}

