#include <QApplication>
#include <QWidget>
#include <QRadioButton>
#include <QButtonGroup>

class RadioButton : public QWidget
{
public:
        RadioButton();

private:
        QRadioButton* RadioButton1;
        QRadioButton* RadioButton2;
        QRadioButton* RadioButton3;
        QRadioButton* RadioButton4;

        QButtonGroup *ButtonGroup;
};

RadioButton::RadioButton()
{
        resize(140, 110);

        ButtonGroup = new QButtonGroup( this );
     //   ButtonGroup->resize(120,110);

        RadioButton1 = new QRadioButton("RadioButton1", this);// ButtonGroup);
        RadioButton1->move(10,10);
        ButtonGroup->addButton(RadioButton1);
        RadioButton2 = new QRadioButton("RadioButton2", this); //ButtonGroup);
        RadioButton2->move(10,30);
        ButtonGroup->addButton(RadioButton2);
        RadioButton3 = new QRadioButton("RadioButton3", this);
        RadioButton3->move(10,50);
        ButtonGroup->addButton(RadioButton3);
        RadioButton4 = new QRadioButton("RadioButton4", this);
        ButtonGroup->addButton(RadioButton4);
        RadioButton4->move(10,70);
}

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        RadioButton RadioButtonWindow;
        RadioButtonWindow.show();

        return app.exec();
}

