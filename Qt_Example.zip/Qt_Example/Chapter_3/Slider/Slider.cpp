#include <QApplication>
#include <QSlider>

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        QSlider* SL = new QSlider(Qt::Horizontal, 0);
        SL->setTickPosition(QSlider::TicksAbove);
        SL->show();

        return app.exec();
}
