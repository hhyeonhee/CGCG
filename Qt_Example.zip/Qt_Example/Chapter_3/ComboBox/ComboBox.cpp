#include <QApplication>
#include <QComboBox>

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        QComboBox* CB = new QComboBox();
        CB->addItem("KDE");
        CB->addItem("Gnome");
        CB->addItem("FVWM");
        CB->addItem("CDE");
        CB->setEditable( TRUE );
        CB->setCurrentIndex(1);
        CB->show();

        return app.exec();
}
