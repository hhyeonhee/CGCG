#include <QApplication>
#include <QDial>

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        QDial* DI = new QDial();
        DI->setNotchesVisible(TRUE);
        DI->setNotchTarget(10);
        DI->show();

        return app.exec();

}
