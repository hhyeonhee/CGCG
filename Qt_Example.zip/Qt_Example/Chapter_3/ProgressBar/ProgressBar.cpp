#include <QApplication>
#include <QProgressBar>

int main( int argc, char** argv )
{
        QApplication app( argc, argv );

        QProgressBar* Pbar = new QProgressBar(); 
          Pbar->setMaximum( 10 );
          Pbar->setTextVisible( TRUE );
        Pbar->setValue( 2 );
        Pbar->show();

        return app.exec();
}
