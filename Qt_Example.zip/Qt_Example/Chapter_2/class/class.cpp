#include <iostream.h>
#include <string.h>

class man {
  private:
        char* Name;
        int Age;
        int Feet;
        int Weight;
  public:
        man(char* name, int age, int feet, int weight);
        void printName();
        void printAge();
        void printFeet();
        void printWeight();
};
 
man::man(char* name, int age, int feet, int weight)
{
        Name = new char[strlen(name)];
 
        strcpy(Name, name);
        Age = age;
        Feet = feet;
        Weight = weight;
}
 
void man::printName()
{
        cout << "Name : " << Name << "\n";
}
 
void man::printAge()
{
        cout << "Age : " << Age << "\n";
}
 
void man::printFeet()
{
        cout << "Feet : " << Feet << "\n";
}

void man::printWeight()
{
         cout << "Weight : " << Weight << "\n";
}
 
int main()
{
        man* Julia = new man("Julia", 23, 168, 55); 
 
        Julia->printName();  
        Julia->printAge();   
        Julia->printFeet();  
        Julia->printWeight();
 
        delete Julia;
 
        return 0;
}

