#include <QApplication>
#include <QPushButton>

#include "MySlotQuit.h"

MySlotQuit::MySlotQuit()
{
       QPushButton *quit = new QPushButton( "Quit", this );
       quit->resize(75, 35);
       QObject::connect(quit, SIGNAL( clicked() ), SLOT( slotQuit() ) );
 }

void MySlotQuit::slotQuit()
{
       qApp->quit();
}

int main( int argc, char **argv )
{
      QApplication app( argc, argv );
      MySlotQuit* quit = new MySlotQuit();
      quit->show();
      return app.exec();
}
