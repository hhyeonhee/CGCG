#include <QWidget>

class MySlotQuit : public QWidget
{
    Q_OBJECT

public:
    MySlotQuit();

public slots:
    void slotQuit();
 };
