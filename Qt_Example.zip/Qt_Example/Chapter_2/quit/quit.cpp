#include <QApplication>
#include <QPushButton>
 
int main( int argc, char **argv )
{
          QApplication app( argc, argv );
          QPushButton *quit = new QPushButton( "Quit", 0 );
          quit->show();
          quit->resize(75, 35);
          return app.exec();
}
