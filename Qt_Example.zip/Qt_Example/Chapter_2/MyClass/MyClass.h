class MyClass : public QWidget
{
    public:
        MyClass();
};
