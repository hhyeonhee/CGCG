#include <qapplication.h>
#include <qpushbutton.h>
#include <qtextcodec.h>
#include <qeuckrcodec.h>
#include <qfont.h>
#include <qstring.h>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	QFont font("gulim", 16);
	qApp->setFont(font);

	QString han("한글");

	QTextCodec* codec = QTextCodec::codecForName("utf8");
	qApp->setDefaultCodec(QTextCodec::codecForLocale());

	QPushButton label(codec->toUnicode(han) , 0);
	label.resize(120, 40);
	label.show();

	app.setMainWidget(&label);
	
	return app.exec();
}
