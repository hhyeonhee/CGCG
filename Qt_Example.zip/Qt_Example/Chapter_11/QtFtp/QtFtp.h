#include <QMainWindow>
#include <QLineEdit>
#include <QListWidget>
#include <QFtp>
#include <QUrlInfo>
#include <QFile>
#include <QHash>
#include <QProgressDialog>
#include <QString>

class QtFtp : public QMainWindow {
	Q_OBJECT
public:
	QtFtp();
	QFtp* ftp;
	QLineEdit* lineedit;
	QListWidget* listwidget;
	QProgressDialog* downloadProgress;
	QFile* file;

public slots:
	int load();
	int stop();
	int addList(const QUrlInfo& urlInfo);
	int downloadFile();
	int chDir(QListWidgetItem* item);
	int updateProgress(qint64 readBytes, qint64 totalBytes);
	int downloadFinish(int i, bool error);

private:
	QHash<QString, bool> isFileType;
};
