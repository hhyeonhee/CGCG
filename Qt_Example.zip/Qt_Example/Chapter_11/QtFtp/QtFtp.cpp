#include <QMenuBar>
#include <QMenu>
#include <QToolBar>
#include <QStatusBar>
#include <QAction>
#include <QIcon>
#include <QTextEdit>
#include <QMessageBox>
#include <QFileDialog>
#include <QFileInfo>
#include <QtGui>

#include "QtFtp.h"

QtFtp::QtFtp()
{
	QToolBar* toolbar;
	QStatusBar* startusbar;
	
	resize(400, 240);

	lineedit = new QLineEdit;

	downloadProgress = new QProgressDialog(this);
	connect(downloadProgress, SIGNAL(canceled()), this, SLOT(stop()));
	
	QAction* quitAct = new QAction("&Quit", this);
        quitAct->setShortcut(tr("Ctrl+Q"));
        quitAct->setStatusTip(tr("Quit Program"));
        connect(quitAct, SIGNAL(triggered()), qApp, SLOT(quit()));

	QAction* stopAct = new QAction("Stop", this);
        stopAct->setShortcut(tr("Ctrl+S"));
        stopAct->setStatusTip(tr("Stop Loading"));
        connect(stopAct, SIGNAL(triggered()), this, SLOT(stop()));
        	
	QAction* loadAct = new QAction("Load", this);
        loadAct->setShortcut(tr("Ctrl+L"));
        loadAct->setStatusTip(tr("Load Page"));
        connect(loadAct, SIGNAL(triggered()), this, SLOT(load()));

	QAction* downloadAct = new QAction("Download", this);
        downloadAct->setShortcut(tr("Ctrl+D"));
        downloadAct->setStatusTip(tr("Download File"));
        connect(downloadAct, SIGNAL(triggered()), this, SLOT(downloadFile()));

        connect(lineedit, SIGNAL(returnPressed()), this, SLOT(load()));
        	
	QMenu* fileMenu = menuBar()->addMenu("File");
	fileMenu->addAction(quitAct);
	QMenu* moveMenu = menuBar()->addMenu("Move");
	moveMenu->addAction(loadAct);
	moveMenu->addAction(stopAct);
	moveMenu->addAction(downloadAct);

	toolbar = addToolBar("New");
	toolbar->addWidget(lineedit);
	toolbar->addAction(loadAct);
	toolbar->addAction(stopAct);
	toolbar->addAction(downloadAct);
		
        startusbar = statusBar();

	listwidget = new QListWidget;
        setCentralWidget(listwidget);
	connect(listwidget, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(chDir(QListWidgetItem*)));
	
	ftp = new QFtp;
	connect(ftp, SIGNAL(listInfo(const QUrlInfo&)), this, SLOT(addList(const QUrlInfo)));
	connect(ftp, SIGNAL(dataTransferProgress(qint64, qint64)), this, SLOT(updateProgress(qint64, qint64)));
	connect(ftp, SIGNAL(commandFinished(int, bool)), this, SLOT(downloadFinish(int, bool)));
}


int QtFtp::updateProgress(qint64 readBytes, qint64 totalBytes)
{
	downloadProgress->setMaximum(totalBytes);
	downloadProgress->setValue(readBytes);

	return 0;
}

int QtFtp::downloadFinish(int i, bool error)
{
	downloadProgress->hide();
	if(file) {
		file->close();
		if(error) file->remove();
		delete file;
	}

	return 0;
}

int QtFtp::stop()
{
	ftp->abort();

	return 0;
}

int QtFtp::load()
{
	ftp->connectToHost(lineedit->text());
	ftp->login("valentis", "sotkfkd");
	ftp->list();

	setWindowTitle(lineedit->text());

	return 0;
}

int QtFtp::downloadFile()
{
	QString fileName = listwidget->currentItem()->text();

	file = new QFile(fileName);
	file->open(QIODevice::WriteOnly);

	ftp->get(fileName, file);

	downloadProgress->setLabelText(QString("Download %1...").arg(fileName));
	downloadProgress->show();

	return 0;
}

int QtFtp::addList(const QUrlInfo& urlInfo)
{
	QListWidgetItem* item = new QListWidgetItem;
	item->setText(urlInfo.name());
	listwidget->addItem(item);
	isFileType[urlInfo.name()] = urlInfo.isDir();

	return 0;
}

int QtFtp::chDir(QListWidgetItem* item)
{
	QString name = item->text();
	if(isFileType.value(name)) {
		listwidget->clear();
		isFileType.clear();
		ftp->cd(name);
		ftp->list();
	}

	return 0;
}
