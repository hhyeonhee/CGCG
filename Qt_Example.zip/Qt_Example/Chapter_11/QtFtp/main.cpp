#include <QApplication>

#include "QtFtp.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	QtFtp* qtftp = new QtFtp();
	qtftp->show();
	
	return app.exec();
}
