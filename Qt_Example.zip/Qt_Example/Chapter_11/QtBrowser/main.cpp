#include <QApplication>

#include "QtBrowser.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	QtBrowser* qtbrowser = new QtBrowser();
	qtbrowser->show();
	
	return app.exec();
}
