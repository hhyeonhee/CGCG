#include <QMainWindow>
#include <QTextEdit>
#include <QLineEdit>
#include <QHttp>

class QtBrowser : public QMainWindow {
	Q_OBJECT
public:
	QtBrowser();
	QHttp* http;
	QTextEdit* textedit;
	QLineEdit* lineedit;

public slots:
	int load();
	int stop();
	int loadDone(bool error);
};
