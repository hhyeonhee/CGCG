#include <QMenuBar>
#include <QMenu>
#include <QToolBar>
#include <QStatusBar>
#include <QAction>
#include <QIcon>
#include <QTextEdit>
#include <QMessageBox>
#include <QFileDialog>
#include <QFileInfo>
#include <QtGui>
#include <QUrl>

#include "QtBrowser.h"

QtBrowser::QtBrowser()
{
	QToolBar* toolbar;
	QStatusBar* startusbar;
	
	resize(320, 240);

	textedit = new QTextEdit;
	textedit->setReadOnly(TRUE);

	lineedit = new QLineEdit;
        connect(lineedit, SIGNAL(returnPressed()), this, SLOT(load()));
	
	QAction* quitAct = new QAction("&Quit", this);
        quitAct->setShortcut(tr("Ctrl+Q"));
        quitAct->setStatusTip(tr("Quit Program"));
        connect(quitAct, SIGNAL(triggered()), qApp, SLOT(quit()));

	QAction* stopAct = new QAction("Stop", this);
        stopAct->setShortcut(tr("Ctrl+S"));
        stopAct->setStatusTip(tr("Stop Loading"));
        connect(stopAct, SIGNAL(triggered()), this, SLOT(stop()));
        	
	QAction* loadAct = new QAction("Load", this);
        loadAct->setShortcut(tr("Ctrl+L"));
        loadAct->setStatusTip(tr("Load Page"));
        connect(loadAct, SIGNAL(triggered()), this, SLOT(load()));

	QMenu* fileMenu = menuBar()->addMenu("File");
	fileMenu->addAction(quitAct);
	QMenu* moveMenu = menuBar()->addMenu("Move");
	moveMenu->addAction(stopAct);
	moveMenu->addAction(loadAct);

	toolbar = addToolBar("New");
	toolbar->addAction(stopAct);
	toolbar->addWidget(lineedit);
	toolbar->addAction(loadAct);
		
        startusbar = statusBar();
        setCentralWidget(textedit);

	http = new QHttp;
}

int QtBrowser::stop()
{
	http->abort();

	return 0;
}

int QtBrowser::load()
{
#if 1
	QUrl url(lineedit->text());
	http->setHost(url.host(), (url.port() != -1)?url.port():80);
	if(!url.userName().isEmpty())
		http->setUser(url.userName(), url.password());

	http->get(url.path());
#else
	http->setHost(lineedit->text());
	http->get("/index.html");
#endif

	connect(http, SIGNAL(done(bool)), this, SLOT(loadDone(bool)));

	return 0;
}

int QtBrowser::loadDone(bool error)
{
	textedit->clear();
	textedit->setHtml(http->readAll());

	return 0;
}
