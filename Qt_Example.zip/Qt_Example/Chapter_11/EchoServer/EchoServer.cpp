#include <QtGui>
#include <QtNetwork>

#include "EchoServer.h"

#define BLOCK_SIZE      1024

EchoServer::EchoServer(QWidget *parent) : QWidget(parent)
{
    Label = new QLabel;
    quitButton = new QPushButton(tr("Quit"));
//    quitButton->setAutoDefault(false);

    tcpServer = new QTcpServer(this);
    if (!tcpServer->listen()) {
        QMessageBox::critical(this, tr("Echo Server"), tr("Unable to start the server: %1.")
                                       .arg(tcpServer->errorString()));
        close();
        return;
    }

    Label->setText(tr("The server is running on port %1.")
                         .arg(tcpServer->serverPort()));

    connect(quitButton, SIGNAL(clicked()), qApp, SLOT(quit()));
    connect(tcpServer, SIGNAL(newConnection()), this, SLOT(echo()));

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(1);
    buttonLayout->addWidget(quitButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(Label);
    mainLayout->addLayout(buttonLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("Echo Server"));
}

void EchoServer::echo()
{
    clientConnection = tcpServer->nextPendingConnection();
    connect(clientConnection, SIGNAL(disconnected()), clientConnection, SLOT(deleteLater()));
    connect(clientConnection, SIGNAL(readyRead()), this, SLOT(readData()));

    Label->setText("new connection is established...");

    //clientConnection->disconnectFromHost();
}

void EchoServer::readData()
{
    QByteArray bytearray;

    if (clientConnection->bytesAvailable() > BLOCK_SIZE)
          return;

    bytearray = clientConnection->read(BLOCK_SIZE);
    QString text(bytearray);
    Label->setText(text);

    clientConnection->write(bytearray);
}
