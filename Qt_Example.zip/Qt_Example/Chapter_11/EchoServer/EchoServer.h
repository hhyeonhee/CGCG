#include <QLabel>
#include <QPushButton>
#include <QTcpServer>
#include <QWidget>
#include <QTcpSocket>

class EchoServer : public QWidget
{
    Q_OBJECT

public:
    EchoServer(QWidget *parent = 0);

private slots:
    void echo();
    void readData();

private:
    QLabel *Label;
    QPushButton *quitButton;
    QTcpServer *tcpServer;
    QTcpSocket * clientConnection;
};
