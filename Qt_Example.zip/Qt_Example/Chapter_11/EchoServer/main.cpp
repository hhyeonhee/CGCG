#include <QApplication>

#include "EchoServer.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    EchoServer server;
    server.show();


    return app.exec();
}
