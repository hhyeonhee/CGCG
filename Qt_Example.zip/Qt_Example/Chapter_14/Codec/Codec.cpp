#include <QApplication>
#include <QString>
#include <QLabel>
#include <QFont>
#include <QTextCodec>

int main(int argc,char **argv) 
{
   QApplication app(argc,argv); 
  
   QFont font("unifont",16,50,FALSE); 
   app.setFont(font); 

   QTextCodec* codec = QTextCodec::codecForName("eucKR"); 
   QString hangul = codec->toUnicode("�ѱ�"); 
 
   QLabel label(hangul); 
   label.resize(150,100); 
   label.show(); 
 
   return app.exec(); 
} 
