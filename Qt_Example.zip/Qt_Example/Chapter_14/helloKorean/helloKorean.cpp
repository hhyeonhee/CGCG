#include <qapplication.h>
#include <qlabel.h>
#include <qstring.h>
#include <qtextcodec.h>
 
#define kor(str) QString::fromUtf8(str)
 
int main( int argc, char **argv )
{
        QApplication app( argc, argv );
        QLabel *hello = new QLabel( "hello", 0 );               
        QTextCodec *codec = QTextCodec::codecForName( "EUC-KR" );
 
        CHECK_PTR( codec );
        if( codec != 0 )
        {
                hello->setText( QString::fromUtf8("�ȳ�") );
        } else {
                hello->setText( codec->toUnicode("�ȳ�") );
        }
 
        app.setMainWidget( hello );
        hello->show();
        
        return app.exec();
}
