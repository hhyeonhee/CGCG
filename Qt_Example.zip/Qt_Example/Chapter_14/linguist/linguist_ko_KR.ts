<!DOCTYPE TS><TS>
<context>
    <name>RadioButton</name>
    <message>
        <source>RadioButton1</source>
        <translation type="unfinished">라디오버튼1</translation>
    </message>
    <message>
        <source>RadioButton2</source>
        <translation type="unfinished">라디오버튼2</translation>
    </message>
    <message>
        <source>RadioButton3</source>
        <translation type="unfinished">라디오버튼3</translation>
    </message>
    <message>
        <source>RadioButton4</source>
        <translation type="unfinished">라디오버튼4</translation>
    </message>
</context>
</TS>
