#include <QtGui>

class RadioButton : public QWidget
{
public:
        RadioButton();

private:
        QRadioButton* RadioButton1;
        QRadioButton* RadioButton2;
        QRadioButton* RadioButton3;
        QRadioButton* RadioButton4;

        QButtonGroup *ButtonGroup;
};

RadioButton::RadioButton()
{
        resize(140, 110);

        QString locale = QLocale::system().name();

        QTranslator translator;
        translator.load("linguist_"+locale);
        qApp->installTranslator(&translator);

        ButtonGroup = new QButtonGroup( this );

        RadioButton1 = new QRadioButton( tr("RadioButton1"), this);
        RadioButton1->move(10,10);
        ButtonGroup->addButton(RadioButton1);
        RadioButton2 = new QRadioButton( tr("RadioButton2"), this); 
        RadioButton2->move(10,30);
        ButtonGroup->addButton(RadioButton2);
        RadioButton3 = new QRadioButton( tr("RadioButton3"), this);
        RadioButton3->move(10,50);
        ButtonGroup->addButton(RadioButton3);
        RadioButton4 = new QRadioButton( locale, this);
        ButtonGroup->addButton(RadioButton4);
        RadioButton4->move(10,70);
}

int main( int argc, char** argv )
{
        Q_INIT_RESOURCE(linguist);

        QApplication app( argc, argv );

        RadioButton RadioButtonWindow;
        RadioButtonWindow.show();

        return app.exec();
}

