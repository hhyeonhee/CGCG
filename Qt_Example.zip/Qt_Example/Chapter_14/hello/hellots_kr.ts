<!DOCTYPE TS><TS>
<context>
    <name>QPushButton</name>
    <message>
        <source>Hello world!</source>
        <translation type="unfinished"> 안녕  world!</translation>
    </message>
</context>
</TS>
