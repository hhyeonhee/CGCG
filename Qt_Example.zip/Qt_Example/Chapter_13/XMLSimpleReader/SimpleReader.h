#ifndef SIMPLEREADER_H
#define SIMPLEREADER_H

#include <QWidget>

class QTreeWidget;

class SimpleReader : public QWidget
{
    Q_OBJECT

public:
    SimpleReader();

private:
    QTreeWidget *treeWidget;
};

#endif			/* SIMPLEREADER_H */
