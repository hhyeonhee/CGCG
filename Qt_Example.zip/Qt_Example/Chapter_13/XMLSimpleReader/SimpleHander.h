#ifndef SIMPLEHANDLER_H
#define SIMPLEHANDLER_H

#include <QXmlDefaultHandler>
#include <QTreeWidget>
#include <QTreeWidgetItem>

class QString;

class SimpleHander : public QXmlDefaultHandler
{
public:
	SimpleHander(QTreeWidget *treeWidget);
    bool startElement( const QString&, const QString&, const QString& ,
                       const QXmlAttributes& );
    bool endElement( const QString&, const QString&, const QString& );

private:
    QString indent;
	QTreeWidget *treeWidget;
    QTreeWidgetItem *item;
};

#endif
