#include <QString>

#include "SimpleHander.h"

SimpleHander::SimpleHander(QTreeWidget *treeWidget)
    : treeWidget(treeWidget)
{
    item = 0;
}

bool SimpleHander::startElement(const QString &,
								 	   const QString &,
                                   const QString &qName,
                                   const QXmlAttributes &attributes)
{
	if(qName == "PhoneNumber") {
        item = new QTreeWidgetItem(treeWidget);
		item->setFlags(item->flags() & ~Qt::ItemIsSelectable);
		item->setData(0, Qt::UserRole, qName);	
        item->setText(0, attributes.value("Name") );
        item->setText(1, attributes.value("TelNo") );
    }

    return TRUE;
}

bool SimpleHander::endElement(const QString &,
                             const QString &,
                             const QString &qName)
{
    return TRUE;
}
