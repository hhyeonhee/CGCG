#include <QtGui>

#include "SimpleReader.h"
#include "SimpleHander.h"

SimpleReader::SimpleReader()
{
    QStringList labels;
    labels << tr("Name") << tr("Telephone No.");

    treeWidget = new QTreeWidget(this);
    treeWidget->header()->setResizeMode(QHeaderView::Stretch);
    treeWidget->setHeaderLabels(labels);
    treeWidget->clear();

	SimpleHander handler(treeWidget);
  
	QXmlSimpleReader reader;
    reader.setContentHandler(&handler);
    reader.setErrorHandler(&handler);

	QFile file("Sample.xml");
    QXmlInputSource xmlInputSource(&file);
    reader.parse(xmlInputSource);

    treeWidget->show();
}
