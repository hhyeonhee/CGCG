#include <QApplication>

#include "SimpleReader.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    SimpleReader simplereader;
    simplereader.show();
    return app.exec();
}
