#include <QtGui>

#include "DOMReader.h"

DOMReader::DOMReader()
{
    QStringList labels;
    labels << tr("Name") << tr("Telephone No.");

    treeWidget = new QTreeWidget(this);
    treeWidget->header()->setResizeMode(QHeaderView::Stretch);
    treeWidget->setHeaderLabels(labels);
    treeWidget->clear();

	QFile file("Sample.xml");
	domDocument.setContent(&file);
    QDomElement docElem = domDocument.documentElement();

    QDomNode node = docElem.firstChild();
    while( !node.isNull() ) {
      QDomElement element = node.toElement();
      if( !element.isNull() ) { 
		if(element.tagName() == "PhoneNumber") {
	        item = new QTreeWidgetItem(treeWidget);
			item->setFlags(item->flags() & ~Qt::ItemIsSelectable);
			item->setData(0, Qt::UserRole, element.tagName());	
	        item->setText(0, element.attribute("Name") );
	        item->setText(1, element.attribute("TelNo") );
		 }
      }
      node = node.nextSibling();
	}

    treeWidget->show();
}
