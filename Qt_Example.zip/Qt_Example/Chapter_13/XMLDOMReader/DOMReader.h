#ifndef DOMREADER_H
#define DOMREADER_H

#include <QWidget>
#include <QDomDocument>
#include <QHash>
#include <QTreeWidgetItem>
#include <QTreeWidget>

class DOMReader : public QWidget
{
    Q_OBJECT

public:
    DOMReader();

private:
    QTreeWidget *treeWidget;
	QTreeWidgetItem *item;
	QDomDocument domDocument;
};

#endif			/* DOMREADER_H */
