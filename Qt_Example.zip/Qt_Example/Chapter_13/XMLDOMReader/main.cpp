#include <QApplication>

#include "DOMReader.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    DOMReader domreader;
    domreader.show();
    return app.exec();
}
