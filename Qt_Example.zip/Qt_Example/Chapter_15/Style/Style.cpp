//#include <QApplication>
#include <QtGui>

int main(int argc, char** argv)
{
   QApplication app(argc, argv);
   QLabel label;

   QComboBox* combo_1 = new QComboBox;
   QComboBox* combo_2 = new QComboBox;
   QComboBox* combo_3 = new QComboBox;
   QComboBox* combo_4 = new QComboBox;
   QComboBox* combo_5 = new QComboBox;
   QComboBox* combo_6 = new QComboBox;
   combo_1->addItem("CDE Style");
   combo_1->setStyle(new QCDEStyle);
   combo_2->addItem("Mac Style");
//   combo_2->setStyle(new QMacStyle);
   combo_3->addItem("Motif Style");
   combo_3->setStyle(new QMotifStyle);
   combo_4->addItem("Windows Style");
   combo_4->setStyle(new QWindowsStyle);
   combo_5->addItem("Plastique Style");
   combo_5->setStyle(new QPlastiqueStyle);
   combo_6->addItem("WindowsXP Style");
//   combo_6->setStyle(new QWindowsXPStyle);

   QGridLayout* layout = new QGridLayout(&label);
   layout->addWidget(combo_1, 0, 0);
   layout->addWidget(combo_2, 0, 1);
   layout->addWidget(combo_3, 0, 2);
   layout->addWidget(combo_4, 1, 0);
   layout->addWidget(combo_5, 1, 1);
   layout->addWidget(combo_6, 1, 2);

   label.show();

   return app.exec();
}
