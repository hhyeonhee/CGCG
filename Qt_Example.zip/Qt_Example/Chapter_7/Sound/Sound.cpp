#include <QApplication>
#include <QSound>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	QSound* sound = new QSound("test.wav");
	sound->play();
	
	return app.exec();
}
