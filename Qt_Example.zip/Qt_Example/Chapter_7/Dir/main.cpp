#include <QApplication>

#include "Dir.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	Dir* dir = new Dir();
	dir->show();
	
	return app.exec();
}
