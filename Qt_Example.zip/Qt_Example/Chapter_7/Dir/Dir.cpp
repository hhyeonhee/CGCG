#include <QFileInfo>
#include <QPushButton>
#include <QVBoxLayout>

#include "Dir.h"

Dir::Dir(QWidget* parent) : QWidget(parent)
{
        int cnt;
        QVBoxLayout* mainLayout = new QVBoxLayout(this);
        dirlist = new QListWidget(this);
        mainLayout->addWidget(dirlist);
        filename = new QLineEdit;
        mainLayout->addWidget(filename);
        QPushButton* makeDir = new QPushButton();
        makeDir->setText("Make Directory");
        mainLayout->addWidget(makeDir);
        QPushButton* removeDir = new QPushButton();
        removeDir->setText("Remove Directory");
        mainLayout->addWidget(removeDir);
        QPushButton* renameDir = new QPushButton();
        renameDir->setText("Rename Directory");
        mainLayout->addWidget(renameDir);
        
        directory = new QDir(".");

        for(cnt = 0; cnt < directory->entryList().count(); cnt++) {
             dirlist->addItem(directory->entryList().at(cnt));
        };

        connect(dirlist, SIGNAL( itemDoubleClicked(QListWidgetItem *) ), this, SLOT( changeDir() ));
        connect(dirlist, SIGNAL( itemClicked(QListWidgetItem *) ), this, SLOT( itemSelected() ));
        connect(makeDir, SIGNAL( clicked() ), this, SLOT( makeDir() ));
        connect(renameDir, SIGNAL( clicked() ), this, SLOT( renameDir() ));
        connect(removeDir, SIGNAL( clicked() ), this, SLOT( removeDir() ));

        setLayout(mainLayout);        
}

int Dir::itemSelected()
{
        filename->setText(dirlist->currentItem()->text());

        return 0;
}

int Dir::changeDir()
{
        int cnt;

        QFileInfo checkDir(dirlist->currentItem()->text());
        if(checkDir.isDir()) {
                directory->cd(dirlist->currentItem()->text());
                dirlist->clear();

                for(cnt = 0; cnt < directory->entryList().count(); cnt++) {
                        dirlist->addItem(directory->entryList().at(cnt));
                };
        }

        return 0;
}

int Dir::makeDir()
{
        int cnt;

        if(!filename->text().length());
                directory->mkdir(filename->text());

        dirlist->clear();
        directory->refresh();
        for(cnt = 0; cnt < directory->entryList().count(); cnt++) {
              dirlist->addItem(directory->entryList().at(cnt));
        };

        return 0;
}

int Dir::removeDir()
{
        int cnt;

        if(!filename->text().length());
                directory->rmdir(filename->text());

        dirlist->clear();
        directory->refresh();
        for(cnt = 0; cnt < directory->entryList().count(); cnt++) {
              dirlist->addItem(directory->entryList().at(cnt));
        };

        return 0;
}

int Dir::renameDir()
{
        int cnt;

        if(!filename->text().length());
                directory->rename(dirlist->currentItem()->text(), filename->text());

        dirlist->clear();
        directory->refresh();
        for(cnt = 0; cnt < directory->entryList().count(); cnt++) {
              dirlist->addItem(directory->entryList().at(cnt));
        };

        return 0;
}
