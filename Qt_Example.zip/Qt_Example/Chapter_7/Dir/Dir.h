#include <QWidget>
#include <QDir>
#include <QListWidget>
#include <QLineEdit>

class Dir : public QWidget {
        Q_OBJECT

  public:
          Dir(QWidget* parent = 0);
          QDir* directory;
          QListWidget* dirlist;
          QLineEdit* filename;
          
  public slots:
          int itemSelected();
          int changeDir();
          int makeDir();
          int removeDir();
          int renameDir();
};
