#include <QMainWindow>
#include <QTextEdit>
#include <QWorkspace>

class QtEditor : public QMainWindow {
	Q_OBJECT
public:
	QtEditor();
	QWorkspace* workspace; 

public slots:
	int newFile();
	int openFile();
	int saveFile();
	int textchanged();
	int showfileinfo();
};
