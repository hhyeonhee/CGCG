#include <QMenuBar>
#include <QMenu>
#include <QToolBar>
#include <QStatusBar>
#include <QAction>
#include <QIcon>
#include <QTextEdit>
#include <QMessageBox>
#include <QFileDialog>
#include <QFileInfo>

#include "QtEditor.h"

QtEditor::QtEditor()
{
	QMenu* fileMenu;
	QToolBar* toolbar;
	QStatusBar* startusbar;
	workspace = new QWorkspace;
	//text_fl = false;
	
	QTextEdit* textedit = new QTextEdit;
	
//	QAction* newAct = new QAction(QIcon("images/new.png"), "&New", this);
	QAction* newAct = new QAction("&New", this);
        newAct->setShortcut(tr("Ctrl+N"));
        newAct->setStatusTip(tr("make new file"));
        connect(newAct, SIGNAL(triggered()), this, SLOT(newFile()));

//	QAction* openAct = new QAction(QIcon("images/open.png"), "&Open", this);
	QAction* openAct = new QAction("&Open", this);
        openAct->setShortcut(tr("Ctrl+O"));
        openAct->setStatusTip(tr("Open existing file"));
        connect(openAct, SIGNAL(triggered()), this, SLOT(openFile()));
	
//	QAction* saveAct = new QAction(QIcon("images/save.png"), "&Save", this);
	QAction* saveAct = new QAction("&Save", this);
        saveAct->setShortcut(tr("Ctrl+S"));
        saveAct->setStatusTip(tr("Save text to file"));
        connect(saveAct, SIGNAL(triggered()), this, SLOT(saveFile()));
	
//	QAction* infoAct = new QAction(QIcon("images/info.png"), "File &Info", this);
	QAction* infoAct = new QAction("File &Info", this);
        infoAct->setShortcut(tr("Ctrl+I"));
        infoAct->setStatusTip(tr("Display File Infomation"));
        connect(infoAct, SIGNAL(triggered()), this, SLOT(showfileinfo()));
        	
	fileMenu = menuBar()->addMenu("File");
	fileMenu->addAction(newAct);
	fileMenu->addAction(openAct);
	fileMenu->addAction(saveAct);
	fileMenu->addAction(infoAct);

	toolbar = addToolBar("New");
	toolbar->addAction(newAct);
	toolbar->addAction(openAct);
	toolbar->addAction(saveAct);
	toolbar->addAction(infoAct);
		
        startusbar = statusBar();
        setCentralWidget(workspace);
        workspace->addWindow(textedit);
	
        connect(textedit, SIGNAL(textChanged()), this, SLOT(textchanged()));
}

int QtEditor::newFile()
{
#if 0
	if(text_fl == true) {
		QMessageBox::information(this, "Text is chnaged", "Save changed text to file.");
		saveFile();
	}
	text_fl = false;
	
	filename.clear();

	textedit->clear();	
#else
	QTextEdit* textedit = new QTextEdit;
        workspace->addWindow(textedit);
        textedit->show();
#endif

	return 0;
}
	
int QtEditor::openFile()
{
#if 1
/*
	if(text_fl == true) {
		QMessageBox::information(this, "Text is chnaged", "Save changed text to file.");
		saveFile();
	}
	
	text_fl = false;
*/
	QByteArray msg;
	QFileDialog* fileDlG = new QFileDialog(this);      	
	QString filename = fileDlG->getOpenFileName(this, "Choose a file", "/home", 
                                        "Plain Text (*.text *.txt *.html)");
	QFile* file = new QFile;
	file->setFileName(filename);
	file->open(QIODevice::ReadOnly);
        msg = file->read(file->size());        // write to stderr
        file->close();
	QTextEdit* textedit = new QTextEdit;
        workspace->addWindow(textedit);
        textedit->setWindowTitle(filename);
        textedit->setPlainText(msg);
        textedit->show();
	
#else
	QErrorMessage* errorMsgDlg = new QErrorMessage(this);
	errorMsgDlg->showMessage ("Error Message");
	errorMsgDlg->exec();
#endif
	


	return 0;
}
	
int QtEditor::saveFile()
{
	QByteArray msg;
	QFile* file = new QFile;
	QTextEdit* textedit = (QTextEdit*)workspace->activeWindow();	
        msg.append(textedit->toPlainText());

        QString filename = textedit->windowTitle();
	if(!filename.length()) 
		filename = QFileDialog::getSaveFileName(this, "Choose a file", \
                                "/home", "Plain Text (*.text *.txt *.html)");

	file->setFileName(filename);
	file->open(QIODevice::WriteOnly);
        file->write(msg);        
        file->close();
	
	return 0;
}

int QtEditor::textchanged()	
{
	//text_fl = true;

	return 0;
}

int QtEditor::showfileinfo()
{
        QString filename = workspace->activeWindow()->windowTitle();	
	QFileInfo* fileinfo = new QFileInfo(filename); 
	QTextEdit* fileinfoDisplay = new QTextEdit;
	QString text;
	text = QString("File path : %1\n size: %2").arg(fileinfo->filePath()).arg(fileinfo->size());
	
	fileinfoDisplay->setReadOnly(TRUE);
	fileinfoDisplay->setPlainText(text); 
	
	workspace->addWindow(fileinfoDisplay);
	fileinfoDisplay->show();
	
	return 0;
}
