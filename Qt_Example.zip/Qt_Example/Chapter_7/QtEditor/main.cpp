#include <QApplication>

#include "QtEditor.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	QtEditor* qteditor = new QtEditor();
	qteditor->show();
	
	return app.exec();
}