#include <QApplication>
#include <QDateTime>
#include <QDateTimeEdit>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);

        QDateTime datetime;
	
	QDateTimeEdit* datetimeedit = new QDateTimeEdit(0);
	datetimeedit->setDateTime(datetime.currentDateTime());
	datetimeedit->show();
	
	return app.exec();
}
