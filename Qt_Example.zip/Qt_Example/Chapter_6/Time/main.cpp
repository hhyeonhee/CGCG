#include <QApplication>
#include <QTime>
#include <QTimeEdit>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);

        QTime time;
	
	QTimeEdit* timeedit = new QTimeEdit(0);
	timeedit->setTime(time.currentTime());
	timeedit->show();
	
	return app.exec();
}
