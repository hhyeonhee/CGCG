#include <QApplication>
#include <QDate>
#include <QDateEdit>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);

        QDate date;
	
	QDateEdit* dateedit = new QDateEdit(0);
	dateedit->setDate(date.currentDate());
	dateedit->show();
	
	return app.exec();
}
