#include <QApplication>

#include "Validator.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	Validator* validator = new Validator();
	validator->show();
	
	return app.exec();
}
