#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QValidator>

class Validator : public QWidget {
	Q_OBJECT
public:
	Validator(QWidget *parent = 0);

private:
        QLabel* label_double;
        QLabel* label_int;
        QLabel* label_regexp;;

        QLineEdit* lineedit_double;
        QLineEdit* lineedit_int;
        QLineEdit* lineedit_regexp;;

        QDoubleValidator* doublevalidator;
        QIntValidator* intvalidator;
        QRegExpValidator* regexpvalidator;
};
