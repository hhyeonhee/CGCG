#include <QDialog>
#include <QGridLayout>
#include <QMessageBox>

#include "Validator.h"

Validator::Validator(QWidget *parent) : QWidget(parent)
{
	resize(320, 240);
        QGridLayout* grid = new QGridLayout;

        label_double = new QLabel(this);
        label_double->setText("Double");
        label_int = new QLabel(this);
        label_int->setText("Int");
        label_regexp = new QLabel(this);
        label_regexp->setText("Regular Expression");

        lineedit_double = new QLineEdit(this);
        lineedit_int = new QLineEdit(this);
        lineedit_regexp = new QLineEdit(this);

        doublevalidator = new QDoubleValidator(this);
        doublevalidator->setTop(10.0);
        doublevalidator->setBottom(-10.0);
        doublevalidator->setDecimals(3);
        lineedit_double->setValidator(doublevalidator);

        intvalidator = new QIntValidator(this);
        intvalidator->setTop(10);
        intvalidator->setBottom(-10);
        lineedit_int->setValidator(intvalidator);

        regexpvalidator = new QRegExpValidator(this);
        regexpvalidator->setRegExp(QRegExp("^\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}"));
        lineedit_regexp->setValidator(regexpvalidator);

        grid->addWidget(label_double, 0, 0);
        grid->addWidget(label_int, 1, 0);
        grid->addWidget(label_regexp, 2, 0);
        grid->addWidget(lineedit_double, 0, 1);
        grid->addWidget(lineedit_int, 1, 1);
        grid->addWidget(lineedit_regexp, 2, 1);

        QObject::connect(lineedit_double, SIGNAL(returnPressed()), this, SLOT(doubleFixup()));
	  
        setLayout(grid);
        setWindowTitle("Validator");
}
