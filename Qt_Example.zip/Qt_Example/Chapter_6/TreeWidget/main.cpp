#include <QApplication>
#include <QTreeWidget>
#include <QTreeWidgetItem>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);

	QTreeWidget* treewidget = new QTreeWidget(0);
        treewidget->setColumnCount(2);

        QTreeWidgetItem* headeritem = new QTreeWidgetItem;
        headeritem->setText(0, "1");
        headeritem->setText(1, "2");
        headeritem->setText(2, "3");
        headeritem->setText(3, "4");
        treewidget->setHeaderItem(headeritem);

        QTreeWidgetItem* item1 = new QTreeWidgetItem(treewidget);
        item1->setText(0, "Item 1");
        item1->setText(1, "Item 2");
        item1->setText(2, "Item 3");
        item1->setText(3, "Item 4");

        QTreeWidgetItem* item2 = new QTreeWidgetItem;
        treewidget->addTopLevelItem(item2);
        item2->setText(0, "Item 5");
        item2->setText(1, "Item 6");
        item2->setText(2, "Item 7");
        item2->setText(3, "Item 8");

        QTreeWidgetItem* item3 = new QTreeWidgetItem(treewidget);
        item3->setText(0, "Item 9");
        item3->setText(1, "Item 10");
        item3->setText(2, "Item 11");
        item3->setText(3, "Item 12");

        QTreeWidgetItem* subItem1 = new QTreeWidgetItem;
        subItem1->setText(0, "subItem 1");
        subItem1->setText(1, "subItem 2");
        subItem1->setText(2, "subItem 3");
        subItem1->setText(3, "subItem 4");
        item2->addChild(subItem1);

        QTreeWidgetItem* subItem2 = new QTreeWidgetItem;
        subItem2->setText(0, "subItem 1");
        subItem2->setText(1, "subItem 2");
        subItem2->setText(2, "subItem 3");
        subItem2->setText(3, "subItem 4");
        item2->addChild(subItem2);

	treewidget->resize(420, 120);
        treewidget->setSortingEnabled(TRUE);
	treewidget->show();
	
	return app.exec();
}
