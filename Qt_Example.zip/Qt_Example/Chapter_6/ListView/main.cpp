#include <QApplication>
#include <QListView>

int main(int argc, char** argv)
{
	QApplication app(argc, argv);

	QListView* listview = new QListView(0);
	listview->show();
	
	return app.exec();
}
