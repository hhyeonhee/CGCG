#include <QApplication>

#include "MoveEvent.h"

int main(int argc, char** argv)
{
   QApplication app(argc, argv);
   MoveEvent* moveevent = new MoveEvent;

   moveevent->show();

   return app.exec();
}
