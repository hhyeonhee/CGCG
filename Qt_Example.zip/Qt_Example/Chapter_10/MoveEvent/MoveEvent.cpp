#include "MoveEvent.h"

MoveEvent::MoveEvent()
{
      label = new QLabel("Hello World", this);
}

void MoveEvent::moveEvent( QMoveEvent * )
{
      label->setText(QString("X : %1, Y : %2").arg(pos().x()).arg(pos().y()));
}
