#include <QLabel>
#include <QWidget>

class MoveEvent:public QWidget
{
     Q_OBJECT

  public:
        MoveEvent();
        QLabel* label;

  private:
        void moveEvent( QMoveEvent * );
};

