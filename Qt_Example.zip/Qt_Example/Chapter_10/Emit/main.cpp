#include <QApplication>

#include "hello.h"

int main(int argc, char** argv)
{
   QApplication app(argc, argv);
   MySlot* hello = new MySlot;

   hello->show();

   sleep(1);
   emit hello->changeLabel();

   return app.exec();
}
