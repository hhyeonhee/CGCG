#include <QLabel>
#include <QWidget>

class MySlot:public QWidget
{
     Q_OBJECT

  public:
        MySlot();
        QLabel* label;

  public slots:
        void changeLabel();
};

