#include "hello.h"

MySlot::MySlot()
{
      label = new QLabel("Hello World", this);
}

void MySlot::changeLabel()
{
      label->setText("Signal/Slot");
}
