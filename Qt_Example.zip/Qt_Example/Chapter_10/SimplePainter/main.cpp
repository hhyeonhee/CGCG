#include <QApplication>

#include "Painter.h"

int main(int argc, char** argv)
{
  QApplication app(argc, argv);
  SimplePainter painter;

  painter.show();
  return app.exec();
}
