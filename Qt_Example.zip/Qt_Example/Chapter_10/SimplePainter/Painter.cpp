#include "Painter.h"

SimplePainter::SimplePainter()
{
  resize(250, 250);
}

void SimplePainter::mousePressEvent(QMouseEvent* e)
{
  point1 = e->pos();
}

void SimplePainter::mouseMoveEvent(QMouseEvent* e)
{
  point2 = e->pos();
  emit paintEvent;
}

void SimplePainter::paintEvent(QPaintEvent* e)
{
  painter = new QPainter;
  painter->begin(this);
  painter->drawLine(point1, point2);
  painter->end();
}


