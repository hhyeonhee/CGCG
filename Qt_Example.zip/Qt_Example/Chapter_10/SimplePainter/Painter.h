#include <QtGui>

class SimplePainter : public QWidget
{
  public:
    SimplePainter();

  protected:
    void mousePressEvent(QMouseEvent*);
    void mouseMoveEvent(QMouseEvent*);
    void paintEvent(QPaintEvent*);

    QPoint point1;
    QPoint point2;
    QPainter* painter;
};
